import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.22d0fef653164274bd1681f3641fafaf',
  appName: 'Travel Companion',
  webDir: 'dist',
  server: {
    url: 'https://22d0fef6-5316-4274-bd16-81f3641fafaf.lovableproject.com?forceHideBadge=true',
    cleartext: true
  }
};

export default config;