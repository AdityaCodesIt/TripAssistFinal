import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Shield, Users, Database, Lock } from "lucide-react";

interface ConsentModalProps {
  open: boolean;
  onConsentGiven: () => void;
  onDecline: () => void;
}

const ConsentModal = ({ open, onConsentGiven, onDecline }: ConsentModalProps) => {
  const [dataConsent, setDataConsent] = useState(false);
  const [researchConsent, setResearchConsent] = useState(false);

  const canProceed = dataConsent && researchConsent;

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-primary">
            <Shield className="w-5 h-5" />
            Research Consent
          </DialogTitle>
          <DialogDescription>
            Help improve transportation planning by sharing your travel data
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <Database className="w-5 h-5 text-primary mt-0.5" />
              <div className="space-y-2">
                <p className="text-sm font-medium">Data Collection</p>
                <p className="text-xs text-muted-foreground">
                  We collect trip details (origin, destination, time, transport mode) to understand travel patterns.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <Users className="w-5 h-5 text-primary mt-0.5" />
              <div className="space-y-2">
                <p className="text-sm font-medium">Research Purpose</p>
                <p className="text-xs text-muted-foreground">
                  Your data helps transportation researchers improve public transit and infrastructure planning.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <Lock className="w-5 h-5 text-primary mt-0.5" />
              <div className="space-y-2">
                <p className="text-sm font-medium">Privacy Protection</p>
                <p className="text-xs text-muted-foreground">
                  All data is anonymized and securely stored. You can delete your data at any time.
                </p>
              </div>
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="data-consent" 
                checked={dataConsent}
                onCheckedChange={(checked) => setDataConsent(checked === true)}
              />
              <label 
                htmlFor="data-consent" 
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                I consent to my travel data being collected
              </label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="research-consent" 
                checked={researchConsent}
                onCheckedChange={(checked) => setResearchConsent(checked === true)}
              />
              <label 
                htmlFor="research-consent" 
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                I consent to my data being used for research purposes
              </label>
            </div>
          </div>
          
          <div className="flex gap-3">
            <Button variant="outline" onClick={onDecline} className="flex-1">
              Decline
            </Button>
            <Button 
              onClick={onConsentGiven}
              disabled={!canProceed}
              className="flex-1 gradient-primary"
            >
              Continue
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ConsentModal;