import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, Users, Calendar } from "lucide-react";

interface TripData {
  tripNumber: string;
  origin: string;
  destination: string;
  startTime: string;
  endTime: string;
  transportMode: string;
  travelerCount: number;
  travelerDetails: string;
}

interface TripListProps {
  trips: TripData[];
}

const TripList = ({ trips }: TripListProps) => {
  if (trips.length === 0) {
    return (
      <Card className="shadow-travel">
        <CardContent className="p-8 text-center">
          <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No trips recorded yet</p>
          <p className="text-sm text-muted-foreground mt-1">Start by adding your first trip above</p>
        </CardContent>
      </Card>
    );
  }

  const getTransportIcon = (mode: string) => {
    // In a real app, you'd have proper icons for each transport mode
    return "🚗"; // Placeholder - could be expanded with proper icon mapping
  };

  const getTransportColor = (mode: string) => {
    const colors: { [key: string]: string } = {
      "Bus": "bg-blue-100 text-blue-800",
      "Train": "bg-green-100 text-green-800", 
      "Car (Driver)": "bg-red-100 text-red-800",
      "Car (Passenger)": "bg-red-50 text-red-600",
      "Walking": "bg-gray-100 text-gray-800",
      "Bicycle": "bg-yellow-100 text-yellow-800",
    };
    return colors[mode] || "bg-primary/10 text-primary";
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold flex items-center gap-2">
        <Calendar className="w-5 h-5 text-primary" />
        Today's Trips ({trips.length})
      </h3>
      
      {trips.map((trip, index) => (
        <Card key={index} className="shadow-travel transition-travel hover:shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  Trip #{trip.tripNumber || index + 1}
                </Badge>
                <Badge className={getTransportColor(trip.transportMode)}>
                  {trip.transportMode}
                </Badge>
              </div>
              {trip.travelerCount > 1 && (
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Users className="w-4 h-4" />
                  {trip.travelerCount}
                </div>
              )}
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-primary" />
                <span className="font-medium">{trip.origin}</span>
                <span className="text-muted-foreground">→</span>
                <span className="font-medium">{trip.destination}</span>
              </div>
              
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {trip.startTime}
                  {trip.endTime && ` - ${trip.endTime}`}
                </div>
              </div>
              
              {trip.travelerDetails && (
                <p className="text-sm text-muted-foreground">
                  Travelers: {trip.travelerDetails}
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default TripList;