import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { 
  MapPin, 
  Calendar, 
  Users, 
  Bus, 
  Car, 
  Bike,
  PersonStanding,
  ChevronDown,
  ChevronUp,
  Plus,
  Loader2,
  Route
} from "lucide-react";
import ConsentModal from "./ConsentModal";
import TripModal from "./TripModal";

interface Trip {
  id: string;
  mode: 'bus' | 'walking' | 'car' | 'bike' | 'school-bus';
  distance: string;
  date: string;
  duration: string;
  origin: string;
  destination: string;
  purpose: string;
  companions: string[];
}

interface RouteData {
  origin: string;
  destination: string;
  transportMode: string;
}

const TripAssistDashboard = () => {
  const [hasConsent, setHasConsent] = useState(false);
  const [showConsentModal, setShowConsentModal] = useState(true);
  const [showTripModal, setShowTripModal] = useState(false);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [routeOpen, setRouteOpen] = useState(false);
  const [routeData, setRouteData] = useState<RouteData>({ origin: '', destination: '', transportMode: '' });
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [loading, setLoading] = useState(false);

  // Sample trips data matching the screenshots
  const sampleTrips: Trip[] = [
    {
      id: '1',
      mode: 'school-bus',
      distance: '7 km',
      date: 'Sep 11, 2025',
      duration: '1 day',
      origin: 'Home',
      destination: 'School',
      purpose: 'Going to school',
      companions: ['Rahul']
    },
    {
      id: '2', 
      mode: 'walking',
      distance: '2.5 km',
      date: 'Sep 10, 2025',
      duration: '2 days',
      origin: 'City Museum',
      destination: 'Hotel',
      purpose: 'Sightseeing',
      companions: ['Priya']
    },
    {
      id: '3',
      mode: 'bus',
      distance: '5 km', 
      date: 'Sep 10, 2025',
      duration: '2 days',
      origin: 'Hotel',
      destination: 'City Museum',
      purpose: 'Sightseeing',
      companions: ['Priya']
    },
    {
      id: '4',
      mode: 'car',
      distance: '5 km',
      date: 'Sep 12, 2025', 
      duration: '4 minutes',
      origin: 'Home',
      destination: 'Gym',
      purpose: 'Physical training',
      companions: ['Krishna', 'Aditya']
    }
  ];

  useEffect(() => {
    const consent = localStorage.getItem('tripassist-consent');
    if (consent === 'true') {
      setHasConsent(true);
      setShowConsentModal(false);
      setTrips(sampleTrips);
    }
  }, []);

  const handleConsentGiven = () => {
    setHasConsent(true);
    setShowConsentModal(false);
    localStorage.setItem('tripassist-consent', 'true');
    setTrips(sampleTrips);
  };

  const getTransportIcon = (mode: string) => {
    switch(mode) {
      case 'bus':
      case 'school-bus':
        return <Bus className="w-5 h-5" />;
      case 'walking':
        return <PersonStanding className="w-5 h-5" />;
      case 'car':
        return <Car className="w-5 h-5" />;
      case 'bike':
        return <Bike className="w-5 h-5" />;
      default:
        return <MapPin className="w-5 h-5" />;
    }
  };

  const getTransportColor = (mode: string) => {
    switch(mode) {
      case 'bus':
        return 'text-blue-600';
      case 'school-bus':
        return 'text-blue-600';
      case 'walking':
        return 'text-green-600';
      case 'car':
        return 'text-red-600';
      case 'bike':
        return 'text-orange-600';
      default:
        return 'text-primary';
    }
  };

  const handleSuggestAlternatives = async () => {
    if (!routeData.origin || !routeData.destination || !routeData.transportMode) return;
    
    setLoading(true);
    setShowSuggestions(false);
    
    // Simulate AI processing
    setTimeout(() => {
      setLoading(false);
      setShowSuggestions(true);
    }, 2000);
  };

  const handleTripSaved = (tripData: any) => {
    const newTrip: Trip = {
      id: Date.now().toString(),
      mode: tripData.transportMode.toLowerCase().replace(' ', '-'),
      distance: '- km',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      duration: 'Just added',
      origin: tripData.origin,
      destination: tripData.destination,
      purpose: tripData.purpose || 'General travel',
      companions: tripData.companions || []
    };
    
    setTrips(prev => [newTrip, ...prev]);
    setShowTripModal(false);
  };

  if (!hasConsent && showConsentModal) {
    return (
      <ConsentModal 
        open={showConsentModal}
        onConsentGiven={handleConsentGiven}
        onDecline={() => setShowConsentModal(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <MapPin className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-semibold text-foreground">TripAssist</h1>
            </div>
            <Button 
              onClick={() => setShowTripModal(true)}
              className="bg-primary hover:bg-primary-hover text-white rounded-lg px-4 py-2 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Log New Trip
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8 space-y-8">
        <h2 className="text-2xl font-semibold text-foreground">Your Travel Diary</h2>
        
        {/* Route Suggestion Section */}
        <Collapsible open={routeOpen} onOpenChange={setRouteOpen}>
          <CollapsibleTrigger className="w-full">
            <Card className="border border-orange-200 bg-orange-50/50 hover:bg-orange-50 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                      <Route className="w-4 h-4 text-orange-600" />
                    </div>
                    <span className="font-medium text-orange-800">Looking for a better route?</span>
                  </div>
                  {routeOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </CardContent>
            </Card>
          </CollapsibleTrigger>
          
          <CollapsibleContent>
            <Card className="mt-4 border-0 shadow-sm bg-muted/30">
              <CardContent className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-red-600 mb-2 block">Origin</label>
                    <Input 
                      placeholder="Your starting point"
                      value={routeData.origin}
                      onChange={(e) => setRouteData({...routeData, origin: e.target.value})}
                      className="border-red-200 focus:border-red-300"
                    />
                    {routeData.origin && <span className="text-xs text-red-500 mt-1 block">Origin is required</span>}
                  </div>
                  <div>
                    <label className="text-sm font-medium text-red-600 mb-2 block">Destination</label>
                    <Input 
                      placeholder="Your end point"
                      value={routeData.destination}
                      onChange={(e) => setRouteData({...routeData, destination: e.target.value})}
                      className="border-red-200 focus:border-red-300"
                    />
                    {routeData.destination && <span className="text-xs text-red-500 mt-1 block">Destination is required</span>}
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-red-600 mb-2 block">Mode of Transport</label>
                  <Input 
                    placeholder="e.g., Bus"
                    value={routeData.transportMode}
                    onChange={(e) => setRouteData({...routeData, transportMode: e.target.value})}
                    className="w-full border-red-200 focus:border-red-300"
                  />
                  {routeData.transportMode && <span className="text-xs text-red-500 mt-1 block">Mode of transport is required</span>}
                </div>
                
                <Button 
                  onClick={handleSuggestAlternatives}
                  disabled={!routeData.origin || !routeData.destination || !routeData.transportMode}
                  className="bg-primary hover:bg-primary-hover text-white"
                >
                  <Route className="w-4 h-4 mr-2" />
                  Suggest Alternatives
                </Button>

                {/* Loading State */}
                {loading && (
                  <div className="text-center py-8">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary mb-2" />
                    <p className="text-muted-foreground">Our AI is finding the best routes for you...</p>
                  </div>
                )}

                {/* Route Suggestions */}
                {showSuggestions && !loading && (
                  <div className="space-y-4">
                    <h4 className="font-medium">Here are some suggestions:</h4>
                    
                    <div className="space-y-3">
                      <Card className="border-l-4 border-l-primary">
                        <CardContent className="p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Bus className="w-4 h-4 text-primary" />
                            <span className="font-medium">Route 1:</span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Take Elm Street to Oak Avenue, then merge onto Main Street closer to the {routeData.destination}. 
                            This route utilizes parallel residential roads to bypass early morning congestion on the primary thoroughfare.
                          </p>
                        </CardContent>
                      </Card>
                      
                      <Card className="border-l-4 border-l-blue-500">
                        <CardContent className="p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Bus className="w-4 h-4 text-blue-500" />
                            <span className="font-medium">Route 2:</span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Follow Maple Lane, then turn onto Pine Road, which will lead directly to the {routeData.destination}. 
                            This route is slightly longer by distance but often has significantly less traffic during peak morning hours.
                          </p>
                        </CardContent>
                      </Card>
                    </div>

                    <Card className="bg-yellow-50 border-yellow-200">
                      <CardContent className="p-4">
                        <h5 className="font-medium text-yellow-800 mb-2">Why these routes?</h5>
                        <p className="text-sm text-yellow-700">
                          Given the morning time and {routeData.transportMode.toLowerCase()} mode of transport from '{routeData.origin}' to '{routeData.destination}', 
                          the primary concern for the current route is likely traffic congestion. The suggested alternative routes aim to bypass 
                          common rush hour bottlenecks and main arterial roads by utilizing parallel residential streets or slightly longer but 
                          less frequented routes. This strategy typically results in a faster and less stressful commute.
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </CardContent>
            </Card>
          </CollapsibleContent>
        </Collapsible>

        {/* Trip Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {trips.map((trip) => (
            <Card key={trip.id} className="shadow-sm hover:shadow-md transition-shadow bg-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className={`flex items-center gap-2 ${getTransportColor(trip.mode)}`}>
                    {getTransportIcon(trip.mode)}
                    <span className="font-medium capitalize">
                      {trip.mode === 'school-bus' ? 'School bus' : trip.mode}
                    </span>
                  </div>
                  <span className="text-sm font-medium">{trip.distance}</span>
                </div>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4 mr-1" />
                    {trip.date} • {trip.duration}
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm">
                    <span className="font-medium">{trip.origin}</span>
                    <span className="text-muted-foreground">→</span>
                    <span className="font-medium">{trip.destination}</span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground">{trip.purpose}</p>
                </div>
                
                {trip.companions.length > 0 && (
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      With {trip.companions.join(', ')}
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </main>

      {/* Trip Modal */}
      <TripModal 
        open={showTripModal}
        onClose={() => setShowTripModal(false)}
        onSave={handleTripSaved}
      />
    </div>
  );
};

export default TripAssistDashboard;