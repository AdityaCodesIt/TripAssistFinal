import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Plus, Trash2, Shuffle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TripModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (tripData: any) => void;
}

const TripModal = ({ open, onClose, onSave }: TripModalProps) => {
  const { toast } = useToast();
  const [tripData, setTripData] = useState({
    origin: '',
    destination: '',
    transportMode: '',
    purpose: '',
    companions: [] as string[]
  });
  
  const [newCompanion, setNewCompanion] = useState('');
  const [showModePrediction, setShowModePrediction] = useState(false);

  const transportModes = [
    "Walking", "Bicycle", "Bike", "Car", "Bus", "Train", "Subway/Metro", "Taxi/Rideshare", "Motorcycle", "Other"
  ];

  const handleAddCompanion = () => {
    if (newCompanion.trim()) {
      setTripData({
        ...tripData,
        companions: [...tripData.companions, newCompanion.trim()]
      });
      setNewCompanion('');
    }
  };

  const handleRemoveCompanion = (index: number) => {
    setTripData({
      ...tripData,
      companions: tripData.companions.filter((_, i) => i !== index)
    });
  };

  const handleTransportModeChange = (mode: string) => {
    setTripData({ ...tripData, transportMode: mode });
    
    // Show prediction for bike mode (matching screenshot)
    if (mode.toLowerCase() === 'bike') {
      setShowModePrediction(true);
      setTimeout(() => setShowModePrediction(false), 3000);
    }
  };

  const handleSave = () => {
    if (!tripData.origin || !tripData.destination || !tripData.transportMode) {
      toast({
        title: "Missing Information",
        description: "Please fill in Origin, Destination, and Mode of Transport",
        variant: "destructive"
      });
      return;
    }

    onSave(tripData);
    
    // Reset form
    setTripData({
      origin: '',
      destination: '',
      transportMode: '',
      purpose: '',
      companions: []
    });
    setNewCompanion('');
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <DialogTitle className="text-lg font-semibold">Log a New Trip</DialogTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Fill in the details of your journey. The more you log, the smarter the app gets!
            </p>
            
            <div className="space-y-2">
              <Label htmlFor="origin" className="text-sm font-medium">Origin</Label>
              <Input
                id="origin"
                placeholder="e.g., Home"
                value={tripData.origin}
                onChange={(e) => setTripData({...tripData, origin: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="destination" className="text-sm font-medium">Destination</Label>
              <Input
                id="destination"
                placeholder="e.g., School"
                value={tripData.destination}
                onChange={(e) => setTripData({...tripData, destination: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="transportMode" className="text-sm font-medium">Mode of Transport</Label>
              <div className="flex gap-2">
                <Select value={tripData.transportMode} onValueChange={handleTransportModeChange}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="e.g., Bus, Walk" />
                  </SelectTrigger>
                  <SelectContent>
                    {transportModes.map((mode) => (
                      <SelectItem key={mode} value={mode}>{mode}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon">
                  <Shuffle className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="purpose" className="text-sm font-medium">Purpose</Label>
              <Input
                id="purpose"
                placeholder="e.g., Going to school, Sightseeing"
                value={tripData.purpose}
                onChange={(e) => setTripData({...tripData, purpose: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium">Companions</Label>
              
              {tripData.companions.map((companion, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Input
                    value={companion}
                    readOnly
                    className="flex-1"
                  />
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => handleRemoveCompanion(index)}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              ))}
              
              <div className="flex items-center gap-2">
                <Input
                  placeholder="Add companion name"
                  value={newCompanion}
                  onChange={(e) => setNewCompanion(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddCompanion()}
                  className="flex-1"
                />
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={handleAddCompanion}
                  disabled={!newCompanion.trim()}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-full justify-start text-muted-foreground"
                onClick={handleAddCompanion}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Companion
              </Button>
            </div>
            
            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={onClose} className="flex-1">
                Cancel
              </Button>
              <Button 
                onClick={handleSave}
                className="flex-1 bg-primary hover:bg-primary-hover text-white"
              >
                Save Trip
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Mode Prediction Toast */}
      {showModePrediction && (
        <div className="fixed bottom-4 right-4 bg-card border shadow-lg rounded-lg p-4 animate-in slide-in-from-bottom-2">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
            <div>
              <p className="font-medium text-sm">Mode Predicted!</p>
              <p className="text-sm text-muted-foreground">We think you're travelling by Bike.</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default TripModal;