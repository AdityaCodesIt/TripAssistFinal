import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Clock, Users, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TripData {
  tripNumber: string;
  origin: string;
  destination: string;
  startTime: string;
  endTime: string;
  transportMode: string;
  travelerCount: number;
  travelerDetails: string;
}

const TripEntryForm = ({ onTripSaved }: { onTripSaved: (trip: TripData) => void }) => {
  const { toast } = useToast();
  const [trip, setTrip] = useState<TripData>({
    tripNumber: '',
    origin: '',
    destination: '',
    startTime: '',
    endTime: '',
    transportMode: '',
    travelerCount: 1,
    travelerDetails: '',
  });

  const transportModes = [
    "Walking", "Bicycle", "Car (Driver)", "Car (Passenger)", 
    "Bus", "Train", "Subway/Metro", "Taxi/Rideshare", "Motorcycle", "Other"
  ];

  const getCurrentTime = () => {
    const now = new Date();
    return now.toTimeString().slice(0, 5);
  };

  const handleSave = () => {
    // Basic validation
    if (!trip.origin || !trip.destination || !trip.transportMode || !trip.startTime) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    onTripSaved(trip);
    
    // Reset form
    setTrip({
      tripNumber: String(Number(trip.tripNumber || '0') + 1),
      origin: '',
      destination: '',
      startTime: '',
      endTime: '',
      transportMode: '',
      travelerCount: 1,
      travelerDetails: '',
    });

    toast({
      title: "Trip Saved",
      description: "Your trip has been recorded successfully",
      className: "bg-success text-success-foreground"
    });
  };

  return (
    <Card className="shadow-travel transition-travel hover:shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Plus className="w-5 h-5 text-primary" />
          New Trip Entry
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="tripNumber">Trip Number</Label>
            <Input
              id="tripNumber"
              placeholder="e.g., 1"
              value={trip.tripNumber}
              onChange={(e) => setTrip({...trip, tripNumber: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="travelerCount">Travelers</Label>
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-muted-foreground" />
              <Input
                id="travelerCount"
                type="number"
                min="1"
                value={trip.travelerCount}
                onChange={(e) => setTrip({...trip, travelerCount: Number(e.target.value)})}
              />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="origin">Origin (Starting Point) *</Label>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-primary" />
            <Input
              id="origin"
              placeholder="Enter starting location"
              value={trip.origin}
              onChange={(e) => setTrip({...trip, origin: e.target.value})}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="destination">Destination *</Label>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-muted-foreground" />
            <Input
              id="destination"
              placeholder="Enter destination"
              value={trip.destination}
              onChange={(e) => setTrip({...trip, destination: e.target.value})}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="startTime">Start Time *</Label>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              <Input
                id="startTime"
                type="time"
                value={trip.startTime}
                onChange={(e) => setTrip({...trip, startTime: e.target.value})}
              />
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setTrip({...trip, startTime: getCurrentTime()})}
              className="w-full text-xs"
            >
              Use Current Time
            </Button>
          </div>
          <div className="space-y-2">
            <Label htmlFor="endTime">End Time</Label>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <Input
                id="endTime"
                type="time"
                value={trip.endTime}
                onChange={(e) => setTrip({...trip, endTime: e.target.value})}
              />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="transportMode">Mode of Transport *</Label>
          <Select value={trip.transportMode} onValueChange={(value) => setTrip({...trip, transportMode: value})}>
            <SelectTrigger>
              <SelectValue placeholder="Select transport mode" />
            </SelectTrigger>
            <SelectContent>
              {transportModes.map((mode) => (
                <SelectItem key={mode} value={mode}>{mode}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {trip.travelerCount > 1 && (
          <div className="space-y-2">
            <Label htmlFor="travelerDetails">Traveler Details</Label>
            <Input
              id="travelerDetails"
              placeholder="e.g., 2 adults, 1 child"
              value={trip.travelerDetails}
              onChange={(e) => setTrip({...trip, travelerDetails: e.target.value})}
            />
          </div>
        )}

        <Button onClick={handleSave} className="w-full gradient-primary">
          Save Trip
        </Button>
      </CardContent>
    </Card>
  );
};

export default TripEntryForm;