import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import ConsentModal from "@/components/ConsentModal";
import TripEntryForm from "@/components/TripEntryForm";
import TripList from "@/components/TripList";
import { MapPin, BarChart3, Settings, Info } from "lucide-react";

interface TripData {
  tripNumber: string;
  origin: string;
  destination: string;
  startTime: string;
  endTime: string;
  transportMode: string;
  travelerCount: number;
  travelerDetails: string;
}

const Dashboard = () => {
  const [hasConsent, setHasConsent] = useState(false);
  const [showConsentModal, setShowConsentModal] = useState(true);
  const [trips, setTrips] = useState<TripData[]>([]);

  useEffect(() => {
    // Check if user has already given consent (in real app, this would be stored)
    const consent = localStorage.getItem('travel-consent');
    if (consent === 'true') {
      setHasConsent(true);
      setShowConsentModal(false);
      
      // Load saved trips
      const savedTrips = localStorage.getItem('travel-trips');
      if (savedTrips) {
        setTrips(JSON.parse(savedTrips));
      }
    }
  }, []);

  const handleConsentGiven = () => {
    setHasConsent(true);
    setShowConsentModal(false);
    localStorage.setItem('travel-consent', 'true');
  };

  const handleConsentDeclined = () => {
    // In a real app, you might redirect or show an explanation
    setShowConsentModal(false);
  };

  const handleTripSaved = (trip: TripData) => {
    const updatedTrips = [...trips, trip];
    setTrips(updatedTrips);
    localStorage.setItem('travel-trips', JSON.stringify(updatedTrips));
  };

  if (!hasConsent && showConsentModal) {
    return (
      <div className="min-h-screen bg-background">
        <ConsentModal 
          open={showConsentModal}
          onConsentGiven={handleConsentGiven}
          onDecline={handleConsentDeclined}
        />
      </div>
    );
  }

  if (!hasConsent) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md shadow-travel">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Info className="w-6 h-6 text-primary" />
              Consent Required
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              You need to provide consent to participate in this transportation research study.
            </p>
            <Button 
              onClick={() => setShowConsentModal(true)}
              className="gradient-primary"
            >
              Review Consent
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MapPin className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">Travel Companion</h1>
                <p className="text-sm text-muted-foreground">Digital Travel Diary</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-success">
                Consent Given
              </Badge>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="shadow-travel">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Today's Trips</p>
                  <p className="text-2xl font-bold text-primary">{trips.length}</p>
                </div>
                <BarChart3 className="w-8 h-8 text-primary/60" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-travel">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Distance</p>
                  <p className="text-2xl font-bold text-primary">-</p>
                </div>
                <MapPin className="w-8 h-8 text-primary/60" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-travel">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg Trip Time</p>
                  <p className="text-2xl font-bold text-primary">-</p>
                </div>
                <BarChart3 className="w-8 h-8 text-primary/60" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Trip Entry Form */}
          <div>
            <TripEntryForm onTripSaved={handleTripSaved} />
          </div>
          
          {/* Trip List */}
          <div>
            <TripList trips={trips} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;